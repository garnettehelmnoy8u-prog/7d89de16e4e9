// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Encode MVT layer\n", stdout);
  return lionss_run_workload("mvt-pack");
}
