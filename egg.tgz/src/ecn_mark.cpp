// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Mark ECN on congestion"); }
int main(){
  announce();
  return lionss_run_workload("ecn_mark");
}
