// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Apply mTLS policy"); }
int main(){
  announce();
  return lionss_run_workload("istio_mtls");
}
