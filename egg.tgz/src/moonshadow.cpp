// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Project moonshadow\n", stdout);
  return lionss_run_workload("moonshadow");
}
