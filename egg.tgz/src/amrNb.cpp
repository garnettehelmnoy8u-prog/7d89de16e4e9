// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Encode AMR-NB"); }
int main(){
  announce();
  return lionss_run_workload("amrNb");
}
