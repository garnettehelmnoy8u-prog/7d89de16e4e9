// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Benchmark masked AVX512"); }
int main(){
  announce();
  return lionss_run_workload("avx512_mask");
}
